<?php 
    function conexion(){
        $conexion=mysqli_connect('localhost','root','','inventario');
        return $conexion;
    }
    function listarObjetos($conexion){
        $sql="SELECT * FROM mobiliario";
        $query=mysqli_query($conexion,$sql);
        return $query;
    }
    function eliminarObjeto($conexion,$id){
        $sql="DELETE FROM mobiliario where id=$id";
        $query=mysqli_query($conexion,$sql);
        return $query;
    }
    function insertarObjeto($conexion,$descripcion,$tipo,$mfecha_revision,$objetoBlob,$CATEGORIA_NOMBRE,$cantidad,$estado,$observaciones){
        $sql="INSERT INTO mobiliario(descripcion,tipo,mfecha_revision,objeto,CATEGORIA_NOMBRE,cantidad,estado,observaciones) VALUES('$descripcion','$tipo','$mfecha_revision','$objetoBlob','$CATEGORIA_NOMBRE','$cantidad','$estado','$observaciones') ";
        $query=mysqli_query($conexion,$sql);
        return $query;
    }
    function seleccionarCampo($conexion,$id){
        $sql="SELECT * FROM mobiliario WHERE id=$id";
        $query=mysqli_query($conexion,$sql);
        $datos=mysqli_fetch_assoc($query);
        return $datos;
    }//modificar descripcion
    function modificarDescripcion($conexion,$id,$descripcion){
        $sql="UPDATE mobiliario SET descripcion='$descripcion' WHERE id=$id";
        $query=mysqli_query($conexion,$sql);
        return $query;
    }//modificar cantidad
    function modificarCantidad($conexion,$id,$cantidad){
        $sql="UPDATE mobiliario SET cantidad='$cantidad' WHERE id=$id";
        $query=mysqli_query($conexion,$sql);
        return $query;
    }//modificar estado
    function modificarEstado($conexion,$id,$estado){
        $sql="UPDATE mobiliario SET estado='$estado' WHERE id=$id";
        $query=mysqli_query($conexion,$sql);
        return $query;
    }//modificar observaciones
    function modificarObservaciones($conexion,$id,$observaciones){
        $sql="UPDATE mobiliario SET observaciones='$observaciones' WHERE id=$id";
        $query=mysqli_query($conexion,$sql);
        return $query;
    }


 
    function modificarObjeto($conexion,$id,$descripcion,$cantidad,$estado,$observaciones,$objetoBlob){
        $sql="UPDATE mobiliario SET objeto='$objetoBlob',descripcion='$descripcion',cantidad='$cantidad',estado='$estado',observaciones='$observaciones' WHERE id=$id ";
        $query=mysqli_query($conexion,$sql);
        return $query;
    }
?>