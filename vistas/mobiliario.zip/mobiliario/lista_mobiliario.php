<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mobiliario Lista</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" crossorigin="anonymous">
	<link rel="" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js">
	<link rel="stylesheet" href="/INVENTARIO-FRONTEND/vistas/css/style.css">
    <link rel="stylesheet" href="/INVENTARIO-FRONTEND/vistas/articulos/style.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/js/bootstrap.min.js" integrity="sha384-o+RDsa0aLu++PJvFqy8fFScvbHFLtbvScb8AjopnFD+iEQ7wo/CG0xlczd+2O/em" crossorigin="anonymous"></script>
</head>
    <!--esilos bootstrap -->
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <!-- nuestros estilos -->
    <link rel="stylesheet" href="style.css">
</head>
<header>
	<div class="contenedor-principal">
		<nav class="navbar navbar-expand-lg " style="background:#39A900;">
			<a href="http://localhost/INVENTARIO-FRONTEND/index.php?vista=home">
			<img src="/INVENTARIO-FRONTEND/img/logosena.JPG">
			</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>		
			</button>
			<div class="collapse navbar-collapse" id="navbarNavDropdown">
				<ul class="navbar-nav">
					
					<li class="nav-item active">
						<div class="menunavegacion">
					<li class="nav-item dropdown" img src="/INVENTARIO-FRONTEND/img/logosena.JPG">
							
						<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Usuarios
						</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink"> 	
							<a class="dropdown-item" href="../../INVENTARIO-FRONTEND/vistas/registrar.php?vista=user_new">Nuevo</a>
							<a class="dropdown-item" href="../../INVENTARIO-FRONTEND/vistas/listas.php?vista=user_list">Lista</a>
						</div>
					</li>
					<!--lista desplegable  esta es-->
                    <li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Categorias</a>
				<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item" href="/INVENTARIO-FRONTEND/vistas/categoria/cate_nuevo.php">Nuevo</a>                            
							<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Listas</a>
							<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
								<a class="dropdown-item" href="../../vistas/Almacenados/listas_almacenados.php?vista=user_new">Almacenado</a>
								<a class="dropdown-item" href="../../vistas/Cables/listas_cables.php?vista=user_list">Cables</a>
                                <a class="dropdown-item" href="/INVENTARIO-FRONTEND/vistas/mobiliario/lista_mobiliario.php">Mobiliario</a>
							</div>
						</div>
					</li>
                    <li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Articulos</a>
				<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item" href="/INVENTARIO-FRONTEND/vistas/articulos/nuevoarticulo.php">Nuevo</a>                            
							<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Listas</a>
							<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
								<a class="dropdown-item" href="../../vistas/Almacenados/listas_almacenados.php?vista=user_new">Articulos</a>
							
							</div>
						</div>
					</li>
</ul>
</li>
			</div>
                    <div class="row">
				<div class="col">
				<a href="actualizar.php?;?>" <button type="button" class="  btn btn-primary" style=" margin-top:-5px; margin-right:100px; "> Mi Cuenta </a> </button>
				</div>
			</div>
			<a href="../index.php" <button type="button" class="btn btn-secondary" style=" margin-top:-5px; margin-right:100px; ">Cerrar sesi&oacute;n </a></button>
	</div>
	</div>
	</div>
	</div>
	</nav>
</header>
<body>
    <div class="container">

<div class="listamobiliario" th colspan="6" class="text-center"> <h1>LISTA DE MOBILIARIO</h1>
<div class="container-fluid">

	<form action="<?=$_SERVER['PHP_SELF']?>" method="post">
		<input class="form-control me-2" type="search" placeholder="Buscador" name="buscar"> <br>
		<button class="btn btn-outline-info" type="submit" name="enviar">Buscar</button>

				<a href="listas.php"> <button class="btn btn-outline-info" type="submit" name="">Mostrar todos los datos</button></a>
							<a href="index.php" <button type="button" class="btn btn-secondary" style=" margin-top:-5px; margin-right:100px; ">Añadir </a></button>

	</form>
</div>

        <div class="row m-0 justify-content-center mt-5">
            <table class="table col-auto w-100">
                <thead>
                    <tr>
                   
                    </tr>
                    <tr>
                        <th>#</th>
                        <th>Descripcion</th>
                        <th></th>
                        <th>Objeto</th>
                        <th>Fecha Revision</th>
                        
                        <th>Categoria nombre</th>
                        <th>Cantidad</th>
                        <th>Estado</th>
                        <th>Observaciones</th>
                        
                        <th>Acciones</th>
</div>

                    </tr>
                </thead>
                <tbody>

                
                
                    <?php 
                        include "/xampp/htdocs/INVENTARIO-FRONTEND/vistas/mobiliario/config/conexion.php";
                 

                        $conexion=conexion();
                        $lista=listarObjetos($conexion);
                        $contador=0;
                        while($datos=mysqli_fetch_array($lista)){
                            $contador++;
                            $id=$datos['id'];
                            $descripcion=$datos['descripcion'];
                            $categoria=$datos['categoria'];
                            $tipo=$datos['tipo'];
                            $objeto=$datos['objeto'];
                            $mfecha_revision=$datos['mfecha_revision'];
                            $CATEGORIA_NOMBRE=$datos['CATEGORIA_NOMBRE'];
                            $cantidad=$datos['cantidad'];
                            $estado=$datos['estado'];
                            $observaciones=$datos['observaciones'];
                            $mensage='';
                             if($categoria=='png' || $categoria=='jpg'){
                                $mensage="<td><img class='icono' src='data:image/jpg;base64,".base64_encode($objeto)."' ></td>";

                            }
                            if($categoria=='pdf'){
                                $mensage="<td><a href='cargar.php?id=$id'><img class='icono' src='img/pdf.png'></br>Abrir</a></td>";
                            }
                            if($categoria=='rar' || $categoria=='zip'){
                                $mensage="<td><a class='text-center' href='cargar.php?id=$id'><img class='icono ' src='img/comprimido.jpg'><br>Descargar</a></td>";
                            }
                            if($categoria=='xls'){
                                $mensage="<td><a class='text-center'  href='cargar.php?id=$id'><img class='icono' src='img/exel.png'><br>descargar</a></td>";
                            }
                            if($categoria=='docx'){
                                $mensage="<td><a class='text-center' href='cargar.php?id=$id'><img class='icono' src='img/word.png'><br>descargar</a></td>";
                            }
                         
                    ?>
                    <tr>
                        
                        <td><?=$contador; ?></td>
                        <td><?=$descripcion; ?></td>
                        <td><?=$categoria; ?></td>
                         <td><img style="max-height:50px;" src="data:image/jpg;base64,<?=base64_encode($objeto)?>"> </td>
                         
                         
                         
                        <!-- <td><img style="max-height:50px;" </td> -->
                        <?php 
                            echo $mensage;
                        ?>
                        
                        <td><?=$mfecha_revision; ?></td>
                        <td><?=$CATEGORIA_NOMBRE; ?></td>
                        <td><?=$cantidad; ?></td>
                        <td><?=$estado; ?></td>
                        <td><?=$observaciones; ?></td> 
                        <!-- hacemos un alert para confirmacion de eliminar-->
                        <td><a class="btn btn-success" href="modificar.php?id=<?=$id?>">Editar</a> <br><br><a class="btn btn-danger" onclick="return ConfirmDelete()" href="acciones/eliminar.php?id=<?=$id;?>">Eliminar</a></td>
                        <script type="text/javascript"> function ConfirmDelete ()

                        
 {
     var respuesta = confirm("Esta seguro de borrar este objeto?");

if (respuesta ==true )
{
    return true;
   
}
else
{
    return false;
}

 } </script>
                    </tr>
                
                    <?php 
                        }
                    ?>
                </tbody>
            </table>
        </div>
        </div>
    </div>
   

    
    <!--js bootstrap -->
    <script src="bootstrap/bootstrap.bundle.min.js"></script>
    


</body>

	
<footer class="main-footerART">
		<strong >Copyright &copy; 2022 <a href="https://comunicaciongraficasena.blogspot.com">Cenigraf</a>.</strong> Todos los derechos reservados.
	</footer>
	
</body>

</html>



