<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<?php 
$conexion=mysqli_connect('localhost','root','','inventario');

    //PAGINACION
    //cantidad de resgistros por pagina
    $por_pagina=5;
    if (isset($_GET['pagina'])) {
        $pagina =$_GET['pagina'];
    }else{
$pagina=1;

    }

    //la pagina inicia en 0 y se multiplica $por_pagina
    $empieza =($pagina=1)* $por_pagina;
    //seleccionar los registros de la tabla
    $query= "SELECT * FROM mobiliario LIMIT $empieza, $por_pagina";
    $resultado=mysqli_query($conexion,$query);

                        ?>

                        <table align="center" border="2" cellpadding="3">
                        <tr>
                        <th>#</th>
                        <th>Descripcion</th>
                        <th></th>
                        <th>Objeto</th>
                        <th>Fecha Revision</th>
                        
                        <th>Categoria nombre</th>
                        <th>Cantidad</th>
                        <th>Estado</th>
                        <th>Observaciones</th>
                        
                        <th>Acciones</th>
                        </tr>
                        <?php 
                        
                        while($fila=mysqli_fetch_assoc($resultado)){
 ?>

                        <tr align="center">
                        <td><?php echo $fila['descripcion'];?></td>
                        <td><?php echo $fila['categoria'];?></td>
                        <td><?php echo $fila['tipo'];?></td>
                        <td><?php echo $fila['objeto'];?></td>
                        <td><?php echo $fila['mfecha_revision'];?></td>
                        <td><?php echo $fila['CATEGORIA_NOMBRE'];?></td>
                        <td><?php echo $fila['cantidad'];?></td>
                        <td><?php echo $fila['estado'];?></td>
                        <td><?php echo $fila['observaciones'];?></td>
                        </tr>
                        <?php 
                         };
                         ?>

                        
                        </table>
                        <?php
                        //seleccionar todo de la tabla mobiliario
                        $query= "SELECT * FROM mobiliario";
                        $resultado=mysqli_query($conexion,$query);
                        //contar el total  de registros
                        $total_registros=mysqli_num_rows($resultado);

                        //cell para dividir el total de registros entre la variable por pagina
                        $total_paginas=ceil($total_registros/$por_pagina);

                        //link a la primera pagina
                        echo "<center><a href='paginacion.php?pagina=1'>".'primera'.'';
                        ?>
</body>
</html> 